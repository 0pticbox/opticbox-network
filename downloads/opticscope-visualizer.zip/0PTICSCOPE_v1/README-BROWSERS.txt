0PTICSCOPE BROWSER BUILDS
Normal index.html = Chrome/Chromium build.
FIREFOX/index.html = Firefox build. It defaults to 0PTIC'S AUDIO BRIDGE.
For Firefox computer-output mode, first run 0PTICS_AUDIO_BRIDGE/START 0PTICS AUDIO BRIDGE.cmd.
