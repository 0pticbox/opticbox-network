NORMAL / CHROME: open index.html.
FIREFOX: start 0PTICS_AUDIO_BRIDGE/START 0PTICS AUDIO BRIDGE.cmd, then open FIREFOX/index.html and press CONNECT 0PTIC'S AUDIO BRIDGE once. Allow Firefox's Device apps & services permission if prompted. Do NOT select the bridge window in Screen Audio.
