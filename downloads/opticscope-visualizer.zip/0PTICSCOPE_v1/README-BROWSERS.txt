0PTICSCOPE — browser builds

NORMAL: index.html — Chrome/Edge and general browser build.
FIREFOX: FIREFOX/index.html — Firefox build with 0PTIC'S AUDIO BRIDGE support.

iPhone/iPad Files (v35):
AUDIO FILE, SVG and image upload controls now use the native file input directly. Audio extensions include WAV/WAVE, MP3, M4A, AAC, AIFF, CAF, FLAC, OGG and OPUS. Choose Browse to open Files/iCloud Drive. If Safari blocks autoplay after selection, tap Play once on the audio control.

Windows Firefox computer audio:
Start 0PTICS_AUDIO_BRIDGE/START 0PTICS AUDIO BRIDGE.cmd, then use CONNECT in the Firefox build.
