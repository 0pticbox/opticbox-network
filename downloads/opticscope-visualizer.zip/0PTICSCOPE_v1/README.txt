0PTICSCOPE

Open index.html in a current Chromium-based desktop browser for the best experience.

Audio inputs:
- MICROPHONE
- AUDIO FILE
- DESKTOP / TAB when the browser provides an audio track

iPhone/iPad Files upload compatibility is included.
