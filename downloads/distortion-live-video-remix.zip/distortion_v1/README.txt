DISTORTION — Live Video Remix Studio (Prototype v1)

HOW TO RUN
1. Unzip the folder.
2. Open index.html in Microsoft Edge or Google Chrome.
3. Upload a song, upload one or more videos, and optionally upload a logo.

CORE CONTROLS
- Hover timeline: instantly jump and play from that position.
- Click timeline: save the position to the armed hot-cue key.
- Hot cues: Q W E R / A S D F / Z X C V
- Distortion: Y U I O / H J K L, plus 7 8 9 0
- Transitions: 1 through 6
- Space: play/pause song
- F1 or ?: help

NOTES
- Allow pop-ups to use DETACH CONTROLS.
- Recording exports WebM and works best in Edge or Chrome.
- The original page must stay open while the detached control window is used.
- Local media files are not uploaded anywhere; they remain in your browser session.


UPDATE 1.1
- Hold Shift and click the timeline to add a new hot cue.
- Normal timeline clicks jump playback without replacing cues.
- Added DESELECT CUE to clear the active menu selection without deleting cue points.


V1.2 UPDATE
- Transitions now hit at full strength instantly and decay quickly.
- Default snap decay is 0.12 seconds.
- Added 8 extreme distortion effects and keyboard mappings.
