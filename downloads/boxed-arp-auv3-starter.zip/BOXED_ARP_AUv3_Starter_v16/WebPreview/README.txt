BOXED ARP v13 BROWSER PREVIEW

Open index.html in a desktop browser.

TEMPO
- SYNC uses the typed or tapped BOXED ARP BPM.
- FREE uses the slow-to-fast speed slider and ignores BPM.
- FREE mode ignores both BPM sources.

PRESETS
- PST only loads factory and custom presets.
- SAVE is the only button that opens the naming window.
- Named arps appear under MY PRESETS.
- DEL removes the selected custom preset.

KEYS
A W S E D F T G Y H U J K play notes.

Custom presets use browser local storage.
The AUv3 source uses UserDefaults.

V15: Expanded to 48 pitch sets plus OFF, including raga-inspired and microtonal cents-based tunings.
