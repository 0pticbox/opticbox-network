# BOXED ARP v16

AUv3 instrument starter for macOS GarageBand-compatible hosts.

## New in v16

- Added a **WORLD SCALES** tab inside the Help menu.
- Includes short lessons for Bhairav, Todi, Marwa, Malkauns, Hamsadhwani, and Charukeshi.
- Each lesson shows its interval formula, C-root note set, and a short description of its character.
- Clarifies that ragas depend on phrasing, ornamentation, emphasis, and pitch movement—not only a fixed scale.

## Factory presets

- INIT
- SKY RUN
- BOSS RUSH
- CRT DREAM
- CHIP FLIGHT
- DARK TOWER
- FREE GLITCH
- AIRSHIP
- MOON TEMPLE
- NEON CASTLE
- STAR CIRCUIT
- FINAL PHASE
- SUNSET SAVE
- ABYSS CHOIR
- ECHO SHRINE
- VIOLET RUINS
- GLASS CATHEDRAL
- GHOST SIGNAL
- DREAM VAULT
- NIGHT ENGINE

## Saving a custom arp

1. Build your arp and sound.
2. Open **PST**.
3. Choose **SAVE CURRENT AS…**.
4. Type a name and press **SAVE**.
5. Reopen it from **PST → MY PRESETS**.

Custom presets store arp, clock, tempo, harmony, oscillators, envelope, filter, delay, transport, MIDI output, and skin settings. Temporary MIDI-capture data is not stored.

## Included features

- Saw, square, and sine oscillators
- Dual-oscillator blend and detune
- ADSR envelope and resonant low-pass filter
- Up, down, up/down, and random arp patterns
- SYNC and FREE clock modes
- 1/4 through 1/64T divisions
- Typed or tapped internal BPM
- Chord presets and scale locking, including Hirajoshi
- Play/Stop, latch, swing, gate, and octave controls
- Generated MIDI output
- MIDI capture and `.mid` export
- Analog delay
- Automatable AU parameters
- Horizontal 720 × 340 interface
- Night, Sky, Crisis, Void, Amber, Ice, and Phosphor skins
- CRT animation that reacts to the sound controls
- Tabbed help overlay with a World Scales learning page

## Folder map

```text
BoxedArpAU/
  Audio/
    BoxedArpAudioUnit.h
    BoxedArpAudioUnit.mm
  DSP/
    BoxedArpDSP.hpp
  UI/
    ArpViewModel.swift
    AudioUnitViewController.swift
    MIDIFileWriter.swift
    PicoArpView.swift
    PicoControls.swift
    PicoTheme.swift
    PixelArpAnimation.swift
    PresetStore.swift
  BoxedArpAU-Bridging-Header.h
  BoxedArpAU.entitlements
  Info.plist
WebPreview/
  index.html
  README.txt
```

# Xcode setup

## 1. Create the containing app

1. Open Xcode on a Mac.
2. Choose **File → New → Project**.
3. Select **macOS → App**.
4. Name it `BoxedArp`.
5. Use Swift.

## 2. Add the Audio Unit extension

1. Choose **File → New → Target**.
2. Select **Audio Unit Extension**.
3. Product Name: `BoxedArpAU`.
4. Audio Unit Type: **Instrument**.
5. Manufacturer Code: `OPTC`.
6. Subtype Code: `BARP`.

```text
Type:         aumu
Subtype:      BARP
Manufacturer: OPTC
Display name: OPTC: BOXED ARP
```

## 3. Add the included source

Delete the generated Audio Unit implementation and view-controller source, but keep the extension target.

Add these folders to the extension target:

- `BoxedArpAU/Audio`
- `BoxedArpAU/DSP`
- `BoxedArpAU/UI`

Also add:

- `BoxedArpAU/BoxedArpAU-Bridging-Header.h`
- `BoxedArpAU/Info.plist`
- `BoxedArpAU/BoxedArpAU.entitlements`

## 4. Target settings

```text
C++ Language Dialect:        C++17
Swift Language Version:      Swift 5
Objective-C Bridging Header: $(SRCROOT)/BoxedArpAU/BoxedArpAU-Bridging-Header.h
Info.plist File:              BoxedArpAU/Info.plist
Code Signing Entitlements:   BoxedArpAU/BoxedArpAU.entitlements
```

## 5. Frameworks

Link:

- AudioToolbox.framework
- AVFoundation.framework
- CoreAudio.framework
- CoreMIDI.framework
- SwiftUI.framework
- AppKit.framework
- UniformTypeIdentifiers.framework

## 6. Build and test

1. Select the containing app scheme.
2. Build and run once.
3. Open GarageBand.
4. Create a Software Instrument track.
5. Load **Audio Units → OPTC → BOXED ARP**.

### Tempo behavior

- SYNC mode reads only the automatable `tempoBPM` parameter.
- The old tempo-source address is reserved internally so later Audio Unit parameter addresses remain compatible.
- FREE arp timing bypasses BPM math and uses `freeRateHz`.
- `tempoBPM` is stored in custom presets and exposed as an AU parameter.

Final Apple SDK compilation, signing, Audio Unit validation, and GarageBand testing require Xcode on a Mac.

## Expanded scale and tuning bank

BOXED ARP v15 includes 48 selectable pitch sets plus OFF. The original scale indices are unchanged so older presets still load correctly. New groups include all seven church modes, melodic-minor modes, symmetric and synthetic scales, Japanese pentatonics, Indian raga-inspired pitch sets, and microtonal tunings.

The raga-inspired entries are intentionally labeled as pitch sets. A complete raga also depends on characteristic ascending/descending motion, emphasized tones, phrases, timing, and ornamentation that a simple quantizer cannot fully reproduce.

Microtonal entries tune the internal synth in cents. Generated MIDI capture also writes standard pitch-bend messages and an RPN setup for a +/-2-semitone bend range, so imported MIDI can preserve the tuning in compatible instruments.
