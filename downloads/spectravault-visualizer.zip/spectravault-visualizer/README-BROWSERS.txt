SPECTRAVAULT — browser builds

NORMAL: index.html — Chrome/Edge and general browser build.
FIREFOX: FIREFOX/index.html — Firefox build with 0PTIC'S AUDIO BRIDGE support.

iPhone/iPad Files (v35):
The AUDIO FILE and logo buttons use the native file input directly instead of a display:none input. Audio extensions include WAV/WAVE, MP3, M4A, AAC, AIFF, CAF, FLAC, OGG and OPUS. Choose Browse to open Files/iCloud Drive. If Safari blocks autoplay after selection, tap Play once on the visible audio control.

Windows Firefox computer audio:
Start 0PTICS_AUDIO_BRIDGE/START 0PTICS AUDIO BRIDGE.cmd, then use CONNECT in the Firefox build.
