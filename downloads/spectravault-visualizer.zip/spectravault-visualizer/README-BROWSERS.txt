SPECTRAVAULT browser package

Open index.html for the Chrome/Chromium build.
Open FIREFOX/index.html for the Firefox-specific audio-input build.
