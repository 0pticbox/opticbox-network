@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  start "SPECTRAVAULT" http://localhost:8080
  py -m http.server 8080
) else (
  echo Python was not found. You can still double-click index.html.
  pause
)
