SPECTRAVAULT VISUAL ENGINE
===========================

A standalone, watermark-free, Winamp-inspired audio visualizer made with HTML, CSS, and JavaScript.
No frameworks, accounts, servers, paid libraries, or online sign-in are required.

CORE VISUALS
------------
1. Kaleido Reactor
2. Neon Tunnel
3. Water Drift
4. Vector Scope
5. Aurora Ribbons
6. Pulse Rings
7. Cube Matrix
8. Pyramid Spire

LATEST CHANGES
--------------
- Auto Flow is much slower and more gradual.
- Each core visual has a longer cycle before moving fully into the next one.
- The transition uses a smooth equal-power crossfade to avoid abrupt dimming or snapping at the midpoint.
- Aurora Ribbons adds layered audio-reactive flowing lines.
- Pulse Rings adds segmented expanding rings with an audio-reactive center.
- Pyramid Spire adds a spinning wireframe pyramid visual related to Cube Matrix.
- Core visual feedback remains at the tuned setting from the prior build.
- Kaleido distortion keeps the cooler brightness setting from the prior build.
- Recording exports MP4 only when the browser supports direct MP4/H.264 recording.

START
-----
1. Open index.html in a current desktop version of Chrome, Edge, Firefox, or Safari.
2. Choose MIC, DESKTOP / TAB, or AUDIO FILE.
3. Pick a core visual or leave Auto Flow on.
4. Press keyboard keys 1 through 9 to toggle distortion effects.
5. Add a PNG/JPG/WebP logo and drag it directly on the visual.
6. Use PICTURE IN PICTURE to float the visual over your desktop if your browser supports it.
7. Choose a recording resolution and press RECORD.
8. Open the built-in HELP tab for the full guide and troubleshooting.

RECORDING
---------
- SPECTRAVAULT adds no watermark.
- Recording is MP4-only in this build.
- The app checks whether the browser can record MP4 directly.
- If MP4/H.264 recording is unavailable, the Record button is disabled instead of producing a mislabeled or incompatible file.
- For desktop or browser-tab audio, enable “Share audio” in the browser share window.
- Browser security may block some features when opened directly from a file. If that happens, run a tiny local server:

  Windows PowerShell, inside this folder:
  python -m http.server 8080

  Then open:
  http://localhost:8080

KEYS
----
1  Kaleido distortion
2  VHS slice jitter
3  Prism Shift
4  Pixel crush
5  Mirror
6  Wave bend
7  Scan Pulse
8  Feedback echo
9  Thermal Map
?  Open or close Help

NOTES
-----
- This project is inspired by classic music visualizers but does not include Winamp or MilkDrop code, presets, logos, or copyrighted assets.
- 1080p recording is more demanding than 720p.
- Leave the browser tab visible while recording for the smoothest output.

PULSE RINGS PERFORMANCE
-----------------------
- Ring segments are batched into one path per ring instead of hundreds of separate strokes.
- Expensive shadow blur was replaced with a faster two-pass glow.
- Ring detail scales intelligently with recording resolution.
- An adaptive quality governor reduces only ring/segment detail when measured FPS falls, then restores full detail after performance recovers.
- This targets 60 FPS at full Motion, Sensitivity, and Feedback settings, though actual results still depend on the computer, browser, output resolution, and any stacked distortion effects.

INTERFACE THEMES
----------------
- CHROME switches the interface to the Chrome Bubble direction: rounded metallic controls, icy highlights, purple/blue chrome, and a bubbly display logo.
- RAVE switches the interface to the Rave Worm direction: warped playful type, yellow/pink/green rave colors, and irregular rounded controls.
- Themes affect the website interface only. They do not alter the recorded visual canvas.
- The selected theme is saved in the browser and restored the next time SPECTRAVAULT opens.

- Picture in Picture can float the live canvas in a small always-on-top window when supported by the browser.

- FX 3, 7, and 9 were replaced with Prism Shift, Scan Pulse, and Thermal Map.

- Vector Scope stays between Water Drift and Aurora Ribbons in both the menu and Auto Flow sequence.
- Pyramid Spire was added to the Core Visual menu and Auto Flow.


- Prism Shift now temporarily lowers only the core visual feedback feeding into the effect, keeping its refracted layers cleaner while leaving normal feedback unchanged when Prism is off.

- Interface fonts were enlarged across menus, buttons, labels, status readouts, dropdowns, themes, and Help text.
