0PS3 browser package

Open index.html for the Chrome/Chromium build.
Open FIREFOX/index.html for the Firefox-specific audio-input build.
The Firefox build can select any audio input exposed by the OS, including Stereo Mix/loopback devices when available.
